from flask import Flask, render_template
import pandas as pd

app = Flask(__name__)

# Load dataset
df = pd.read_csv("data/flights.csv")

@app.route("/")
def home():
    return render_template("index.html", title="Dashboard", table=None)

@app.route("/filter/delayed30")
def delayed30():
    result = df[df["DepartureDelay"] > 30]
    return render_template("index.html",
                           title="Flights Delayed > 30 mins",
                           table=result.to_html(classes="table table-bordered table-striped", index=False))

@app.route("/filter/jfk")
def jfk():
    result = df[df["OriginAirport"] == "JFK"]
    return render_template("index.html",
                           title="Flights from JFK",
                           table=result.to_html(classes="table table-bordered table-striped", index=False))

@app.route("/filter/delta")
def delta():
    result = df[df["Airline"] == "Delta"]
    return render_template("index.html",
                           title="Flights by Delta",
                           table=result.to_html(classes="table table-bordered table-striped", index=False))

@app.route("/summary/airlines")
def summary_airlines():
    result = df.groupby("Airline").agg(
        avg_departure_delay=("DepartureDelay", "mean"),
        total_flights=("FlightID", "count")
    ).reset_index()
    return render_template("index.html",
                           title="Airline Summary",
                           table=result.to_html(classes="table table-bordered table-striped", index=False))

@app.route("/summary/airports")
def summary_airports():
    result = df.groupby("OriginAirport").agg(
        total_flights=("FlightID", "count"),
        delayed_flights=("DepartureDelay", lambda x: (x > 0).sum())
    )
    result["percent_delayed"] = (result["delayed_flights"]/result["total_flights"]*100)
    result = result.reset_index()
    return render_template("index.html",
                           title="Airport Summary",
                           table=result.to_html(classes="table table-bordered table-striped", index=False))

@app.route("/summary/routes")
def summary_routes():
    temp = df.copy()
    temp["Route"] = temp["OriginAirport"] + "-" + temp["DestinationAirport"]
    result = temp.groupby("Route").agg(
        avg_delay=("DepartureDelay", "mean"),
        total_flights=("FlightID", "count")
    ).reset_index()
    return render_template("index.html",
                           title="Route Summary",
                           table=result.to_html(classes="table table-bordered table-striped", index=False))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
