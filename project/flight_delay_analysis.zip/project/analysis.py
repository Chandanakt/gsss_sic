import pandas as pd

# 1. Load dataset
df = pd.read_csv("data/flights.csv")

# Clean up column names (remove spaces, standardize)
df.columns = df.columns.str.strip()

# 2. Explore dataset
print("---- HEAD ----")
print(df.head())
print("\n---- INFO ----")
print(df.info())
print("\n---- DESCRIBE ----")
print(df.describe(include="all"))

# 3. Filtering
print("\n---- FILTERING ----")

# Flights delayed more than 30 mins
delayed_30 = df[df["DepartureDelay"] > 30]
print("Flights delayed > 30 mins:\n", delayed_30)

# Flights from JFK
jfk_flights = df[df["OriginAirport"] == "JFK"]
print("\nFlights from JFK:\n", jfk_flights)

# Flights by Delta
delta_flights = df[df["Airline"] == "Delta"]
print("\nFlights by Delta:\n", delta_flights)

# 4. Grouping
print("\n---- GROUPING ----")

# By Airline → average delay, total flights
airline_summary = df.groupby("Airline").agg(
    avg_departure_delay=("DepartureDelay", "mean"),
    total_flights=("FlightID", "count")
).reset_index()
print("\nAirline Summary:\n", airline_summary)

# By OriginAirport → total flights, % delayed
airport_summary = df.groupby("OriginAirport").agg(
    total_flights=("FlightID", "count"),
    delayed_flights=("DepartureDelay", lambda x: (x > 0).sum())
)
airport_summary["percent_delayed"] = (
    airport_summary["delayed_flights"] / airport_summary["total_flights"] * 100
)
airport_summary = airport_summary.reset_index()
print("\nAirport Summary:\n", airport_summary)

# By Date → daily average delay
date_summary = df.groupby("Date").agg(
    daily_avg_delay=("DepartureDelay", "mean")
).reset_index()
print("\nDate Summary:\n", date_summary)

# By Origin–Destination route → avg delay
df["Route"] = df["OriginAirport"] + "-" + df["DestinationAirport"]
route_summary = df.groupby("Route").agg(
    avg_delay=("DepartureDelay", "mean"),
    total_flights=("FlightID", "count")
).reset_index()
print("\nRoute Summary:\n", route_summary)

# 5. Export summaries
airline_summary.to_csv("airline_summary.csv", index=False)
airport_summary.to_csv("airport_summary.csv", index=False)
route_summary.to_csv("route_summary.csv", index=False)

print("\n✅ Summaries exported: airline_summary.csv, airport_summary.csv, route_summary.csv")
