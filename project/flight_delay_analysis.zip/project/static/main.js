console.log("✅ main.js loaded");

async function loadData(endpoint, type = null) {
  console.log("Fetching:", endpoint);

  try {
    const res = await fetch(endpoint);
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

    const data = await res.json();
    console.log("Response:", data);

    const table = document.getElementById("summary-table");
    const thead = table.querySelector("thead");
    const tbody = table.querySelector("tbody");

    thead.innerHTML = "";
    tbody.innerHTML = "";

    if (!Array.isArray(data) || !data.length) {
      tbody.innerHTML = "<tr><td colspan='100%'>No data available</td></tr>";
      return;
    }

    // Build table headers
    const headers = Object.keys(data[0]);
    thead.innerHTML = "<tr>" + headers.map(h => `<th>${h}</th>`).join("") + "</tr>";

    // Build table rows
    data.forEach(row => {
      const rowHtml = "<tr>" + headers.map(h => `<td>${row[h]}</td>`).join("") + "</tr>";
      tbody.innerHTML += rowHtml;
    });

    // Update title
    let title = "Results";
    if (type === "airlines") title = "Airline Summary";
    else if (type === "airports") title = "Airport Summary";
    else if (type === "routes") title = "Route Summary";
    else if (endpoint.includes("delayed30")) title = "Flights Delayed > 30 mins";
    else if (endpoint.includes("jfk")) title = "Flights from JFK";
    else if (endpoint.includes("delta")) title = "Flights by Delta";

    document.getElementById("summary-title").innerText = title;

    // CSV download
    const downloadLink = document.getElementById("download-link");
    if (type) {
      downloadLink.classList.remove("d-none");
      downloadLink.href = `/api/export/${type}`;
    } else {
      downloadLink.classList.add("d-none");
    }

  } catch (err) {
    console.error("❌ Fetch failed:", err);
    alert("⚠️ Failed to fetch data. Check console.");
  }
}
